"""Utility functions for LIPAC."""
