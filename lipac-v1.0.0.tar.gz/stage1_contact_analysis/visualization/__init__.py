"""Visualization module for LIPAC."""
