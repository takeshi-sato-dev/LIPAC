"""Core module for LIPAC contact analysis."""
